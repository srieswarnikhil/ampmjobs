package com.quantum.ampmjobs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmpmjobsApplicationTests {

	@Test
	void contextLoads() {
	}

}
