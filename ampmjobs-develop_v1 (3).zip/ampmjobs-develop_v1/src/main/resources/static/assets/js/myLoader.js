function showLoader() {
	$('#loader').fadeIn();
}

function hideLoader() {
	$('#loader').fadeOut();
}